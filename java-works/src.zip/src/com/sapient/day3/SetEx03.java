package com.sapient.day3;

import java.util.TreeSet;

public class SetEx03 {
	public static void main(String[] args)
	{
		TreeSet<String> names=new TreeSet<String>();
		names.add("Mayank");
		names.add("Roopesh");

		names.add("Sid");
		names.add("Yash");
		names.add("Mahesh");
		
		System.out.println(names);
		
	}

}
